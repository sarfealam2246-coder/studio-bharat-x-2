import {
  BhojpuriCharacterSlot,
  BhojpuriStoryPlan,
  GitHubReelRepoConfig,
  ReelVfxSettings,
  StoredBhojpuriReel,
  TimelineClipItem,
} from '../types/studio';
import { synthesizeStudioVoiceBuffer } from './cloudTtsService';
import { studioBus } from './eventBus';
import { loadSecretsVault } from './secretsService';

export const REELS_DB_NAME = 'studio_bharat_x_reels_v1';
const REELS_STORE_NAME = 'reels';
const REELS_META_FALLBACK_KEY = 'studio_bharat_x_reels_meta_v1';
const GITHUB_REPO_CFG_KEY = 'studio_bharat_x_github_reel_cfg_v1';
const REEL_BADGE_KEY = 'studio_bharat_x_reel_badge_v1';

const GITHUB_API_TIMEOUT_MS = 12_000;

export const DEFAULT_REEL_VFX: ReelVfxSettings = {
  zoomMotion: true,
  comedyShake: true,
  bhojpuriSubtitles: true,
  sfx: true,
};

function openReelsDb(): Promise<IDBDatabase | null> {
  return new Promise((resolve) => {
    if (typeof window === 'undefined' || !('indexedDB' in window)) {
      resolve(null);
      return;
    }
    try {
      const request = window.indexedDB.open(REELS_DB_NAME, 1);
      request.onupgradeneeded = () => {
        const db = request.result;
        if (!db.objectStoreNames.contains(REELS_STORE_NAME)) {
          db.createObjectStore(REELS_STORE_NAME, { keyPath: 'id' });
        }
      };
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => resolve(null);
    } catch {
      resolve(null);
    }
  });
}

function saveReelsMetaFallback(reels: StoredBhojpuriReel[]): void {
  try {
    const slim = reels.map(({ blob: _blob, ...rest }) => rest);
    window.localStorage.setItem(REELS_META_FALLBACK_KEY, JSON.stringify(slim));
  } catch {
    // Non-blocking fallback
  }
}

function loadReelsMetaFallback(): StoredBhojpuriReel[] {
  try {
    const raw = window.localStorage.getItem(REELS_META_FALLBACK_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw) as unknown;
    return Array.isArray(parsed) ? (parsed as StoredBhojpuriReel[]) : [];
  } catch {
    return [];
  }
}

export async function listStoredReels(): Promise<StoredBhojpuriReel[]> {
  const db = await openReelsDb();
  if (!db) {
    return loadReelsMetaFallback().sort((a, b) => b.createdAt - a.createdAt);
  }
  return new Promise((resolve) => {
    try {
      const tx = db.transaction(REELS_STORE_NAME, 'readonly');
      const req = tx.objectStore(REELS_STORE_NAME).getAll();
      req.onsuccess = () => {
        const list = (Array.isArray(req.result) ? req.result : []) as StoredBhojpuriReel[];
        list.sort((a, b) => b.createdAt - a.createdAt);
        resolve(list);
      };
      req.onerror = () => resolve(loadReelsMetaFallback());
    } catch {
      resolve(loadReelsMetaFallback());
    }
  });
}

export async function saveStoredReel(reel: StoredBhojpuriReel): Promise<StoredBhojpuriReel> {
  const db = await openReelsDb();
  if (db) {
    await new Promise<void>((resolve) => {
      try {
        const tx = db.transaction(REELS_STORE_NAME, 'readwrite');
        tx.objectStore(REELS_STORE_NAME).put(reel);
        tx.oncomplete = () => resolve();
        tx.onerror = () => resolve();
      } catch {
        resolve();
      }
    });
  }
  const all = await listStoredReels();
  const merged = [reel, ...all.filter((r) => r.id !== reel.id)];
  saveReelsMetaFallback(merged);
  return reel;
}

export async function deleteStoredReel(reelId: string): Promise<void> {
  const db = await openReelsDb();
  if (db) {
    await new Promise<void>((resolve) => {
      try {
        const tx = db.transaction(REELS_STORE_NAME, 'readwrite');
        tx.objectStore(REELS_STORE_NAME).delete(reelId);
        tx.oncomplete = () => resolve();
        tx.onerror = () => resolve();
      } catch {
        resolve();
      }
    });
  }
  const remaining = loadReelsMetaFallback().filter((r) => r.id !== reelId);
  saveReelsMetaFallback(remaining);
}

export async function markStoredReelPublished(
  reelId: string,
  publishedVideoId: string
): Promise<StoredBhojpuriReel | null> {
  const all = await listStoredReels();
  const found = all.find((r) => r.id === reelId);
  if (!found) return null;
  const updated: StoredBhojpuriReel = {
    ...found,
    publishedVideoId,
    publishedAt: Date.now(),
  };
  await saveStoredReel(updated);
  return updated;
}

export function loadUnreadCloudReelFlag(): boolean {
  try {
    return window.localStorage.getItem(REEL_BADGE_KEY) === '1';
  } catch {
    return false;
  }
}

export function setUnreadCloudReelFlag(unread: boolean): void {
  try {
    window.localStorage.setItem(REEL_BADGE_KEY, unread ? '1' : '0');
  } catch {
    // Non-blocking
  }
}

export function loadGitHubReelConfig(): GitHubReelRepoConfig {
  try {
    const raw = window.localStorage.getItem(GITHUB_REPO_CFG_KEY);
    if (!raw) return { owner: '', repo: 'studio-bharat-x-reels', branch: 'main' };
    const parsed = JSON.parse(raw) as Partial<GitHubReelRepoConfig>;
    return {
      owner: typeof parsed.owner === 'string' ? parsed.owner.trim() : '',
      repo:
        typeof parsed.repo === 'string' && parsed.repo.trim()
          ? parsed.repo.trim()
          : 'studio-bharat-x-reels',
      branch:
        typeof parsed.branch === 'string' && parsed.branch.trim()
          ? parsed.branch.trim()
          : 'main',
    };
  } catch {
    return { owner: '', repo: 'studio-bharat-x-reels', branch: 'main' };
  }
}

export function saveGitHubReelConfig(cfg: GitHubReelRepoConfig): GitHubReelRepoConfig {
  const clean: GitHubReelRepoConfig = {
    owner: cfg.owner.trim(),
    repo: cfg.repo.trim() || 'studio-bharat-x-reels',
    branch: cfg.branch.trim() || 'main',
  };
  try {
    window.localStorage.setItem(GITHUB_REPO_CFG_KEY, JSON.stringify(clean));
  } catch {
    // Non-blocking
  }
  return clean;
}

export function buildTimelineFromStory(story: BhojpuriStoryPlan | null): TimelineClipItem[] {
  if (!story || story.scenes.length === 0) return [];
  return story.scenes.map((scene) => ({
    id: `scene_clip_${story.id}_${scene.sceneNumber}`,
    kind: 'scene-image',
    label: `Scene ${scene.sceneNumber} · ${scene.speaker}`,
    sceneNumber: scene.sceneNumber,
    imageUrl: scene.imageUrl,
    durationSec: scene.durationSec,
    trimStartSec: 0,
    trimEndSec: scene.durationSec,
    dialogue: scene.dialogue,
    subtitle: scene.subtitle,
    speaker: scene.speaker,
    voicePersona: scene.voicePersona,
    sfxCue: scene.sfxCue,
  }));
}

export function probeVideoDuration(objectUrl: string): Promise<number> {
  return new Promise((resolve) => {
    const video = document.createElement('video');
    video.preload = 'metadata';
    video.muted = true;
    const cleanup = () => {
      video.onloadedmetadata = null;
      video.onerror = null;
      video.src = '';
    };
    const fallbackTimer = window.setTimeout(() => {
      cleanup();
      resolve(6);
    }, 3000);
    video.onloadedmetadata = () => {
      window.clearTimeout(fallbackTimer);
      const dur = Number.isFinite(video.duration) && video.duration > 0.5 ? video.duration : 6;
      cleanup();
      resolve(Math.min(20, Math.max(2, Math.round(dur * 10) / 10)));
    };
    video.onerror = () => {
      window.clearTimeout(fallbackTimer);
      cleanup();
      resolve(6);
    };
    video.src = objectUrl;
  });
}

export async function createClipFromUploadedVideo(
  file: File,
  index: number,
  story: BhojpuriStoryPlan | null
): Promise<TimelineClipItem> {
  const objectUrl = URL.createObjectURL(file);
  const detectedDuration = await probeVideoDuration(objectUrl);
  const matchedScene = story?.scenes[index] ?? story?.scenes[index % Math.max(1, story.scenes.length)];
  const sceneDur = matchedScene ? Math.min(detectedDuration, matchedScene.durationSec) : Math.min(detectedDuration, 8);

  return {
    id: `flow_clip_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 6)}`,
    kind: 'flow-video',
    label: file.name.replace(/\.[^.]+$/, '').slice(0, 32) || `Flow Clip ${index + 1}`,
    sceneNumber: matchedScene?.sceneNumber ?? index + 1,
    objectUrl,
    imageUrl: matchedScene?.imageUrl,
    durationSec: detectedDuration,
    trimStartSec: 0,
    trimEndSec: Math.max(2, Math.round(sceneDur * 10) / 10),
    dialogue: matchedScene?.dialogue ?? '',
    subtitle: matchedScene?.subtitle ?? file.name.replace(/\.[^.]+$/, ''),
    speaker: matchedScene?.speaker ?? 'Cast',
    voicePersona: matchedScene?.voicePersona ?? 'Puck',
    sfxCue: matchedScene?.sfxCue ?? 'cartoon pop',
  };
}

/**
 * Procedural Web Audio comedy SFX synthesizer (boing, slide whistle, dhol pop, punchline sting).
 */
export function triggerComedySfx(
  audioCtx: AudioContext,
  destination: AudioNode,
  cue: string,
  whenSec?: number
): void {
  const t0 = whenSec ?? audioCtx.currentTime;
  const lower = cue.toLowerCase();

  const osc = audioCtx.createOscillator();
  const gain = audioCtx.createGain();
  osc.connect(gain);
  gain.connect(destination);

  if (lower.includes('whistle') || lower.includes('cooker') || lower.includes('slide')) {
    osc.type = 'sine';
    osc.frequency.setValueAtTime(520, t0);
    osc.frequency.exponentialRampToValueAtTime(1480, t0 + 0.22);
    osc.frequency.exponentialRampToValueAtTime(740, t0 + 0.38);
    gain.gain.setValueAtTime(0.001, t0);
    gain.gain.linearRampToValueAtTime(0.16, t0 + 0.04);
    gain.gain.exponentialRampToValueAtTime(0.001, t0 + 0.42);
    osc.start(t0);
    osc.stop(t0 + 0.44);
  } else if (lower.includes('boing') || lower.includes('shock') || lower.includes('twist')) {
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(175, t0);
    osc.frequency.exponentialRampToValueAtTime(520, t0 + 0.14);
    osc.frequency.exponentialRampToValueAtTime(210, t0 + 0.28);
    osc.frequency.exponentialRampToValueAtTime(420, t0 + 0.4);
    gain.gain.setValueAtTime(0.001, t0);
    gain.gain.linearRampToValueAtTime(0.22, t0 + 0.03);
    gain.gain.exponentialRampToValueAtTime(0.001, t0 + 0.44);
    osc.start(t0);
    osc.stop(t0 + 0.46);
  } else {
    // Classic desi comic pop / dhol punch
    osc.type = 'sine';
    osc.frequency.setValueAtTime(260, t0);
    osc.frequency.exponentialRampToValueAtTime(92, t0 + 0.18);
    gain.gain.setValueAtTime(0.001, t0);
    gain.gain.linearRampToValueAtTime(0.24, t0 + 0.015);
    gain.gain.exponentialRampToValueAtTime(0.001, t0 + 0.22);
    osc.start(t0);
    osc.stop(t0 + 0.25);
  }
}

function drawRoundedRect(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  r: number
): void {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.lineTo(x + w - r, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + r);
  ctx.lineTo(x + w, y + h - r);
  ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
  ctx.lineTo(x + r, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - r);
  ctx.lineTo(x, y + r);
  ctx.quadraticCurveTo(x, y, x + r, y);
  ctx.closePath();
}

function wrapCanvasText(
  ctx: CanvasRenderingContext2D,
  text: string,
  maxWidth: number,
  maxLines: number
): string[] {
  const words = text.trim().split(/\s+/).filter(Boolean);
  const lines: string[] = [];
  let current = '';

  for (const word of words) {
    const candidate = current ? `${current} ${word}` : word;
    if (ctx.measureText(candidate).width <= maxWidth) {
      current = candidate;
    } else {
      if (current) lines.push(current);
      current = word;
      if (lines.length >= maxLines - 1) break;
    }
  }
  if (current && lines.length < maxLines) {
    lines.push(current);
  }
  return lines;
}

export function paintReelCanvasFrame(params: {
  ctx: CanvasRenderingContext2D;
  width: number;
  height: number;
  clip: TimelineClipItem;
  progress: number; // 0..1 inside clip
  vfx: ReelVfxSettings;
  mediaSource: HTMLImageElement | HTMLVideoElement | null;
  reelTitle: string;
}): void {
  const { ctx, width, height, clip, progress, vfx, mediaSource, reelTitle } = params;

  ctx.save();
  ctx.fillStyle = '#0A0B0E';
  ctx.fillRect(0, 0, width, height);

  // VFX transforms: Zoom Motion + Comedy Shake
  const zoomScale = vfx.zoomMotion ? 1 + progress * 0.11 : 1;
  let shakeX = 0;
  let shakeY = 0;
  if (vfx.comedyShake && (progress < 0.14 || (progress > 0.72 && progress < 0.88))) {
    const phase = progress * 75;
    shakeX = Math.sin(phase * 1.7) * 7;
    shakeY = Math.cos(phase * 2.1) * 5;
  }

  ctx.save();
  ctx.translate(width / 2 + shakeX, height / 2 + shakeY);
  ctx.scale(zoomScale, zoomScale);
  ctx.translate(-width / 2, -height / 2);

  if (mediaSource) {
    const srcW =
      mediaSource instanceof HTMLVideoElement
        ? mediaSource.videoWidth || width
        : mediaSource.naturalWidth || width;
    const srcH =
      mediaSource instanceof HTMLVideoElement
        ? mediaSource.videoHeight || height
        : mediaSource.naturalHeight || height;

    const coverScale = Math.max(width / Math.max(1, srcW), height / Math.max(1, srcH));
    const drawW = srcW * coverScale;
    const drawH = srcH * coverScale;
    const dx = (width - drawW) / 2;
    const dy = (height - drawH) / 2;
    ctx.drawImage(mediaSource, dx, dy, drawW, drawH);
  } else {
    // Stylized obsidian & warm saffron animated backdrop when 3D image isn't rendered yet
    const grad = ctx.createLinearGradient(0, 0, width, height);
    grad.addColorStop(0, '#1B1411');
    grad.addColorStop(0.5, '#12151E');
    grad.addColorStop(1, '#090B0F');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, width, height);

    ctx.fillStyle = 'rgba(245, 158, 11, 0.14)';
    ctx.beginPath();
    ctx.arc(
      width * (0.3 + 0.4 * Math.sin(progress * Math.PI)),
      height * 0.34,
      width * 0.34,
      0,
      Math.PI * 2
    );
    ctx.fill();

    ctx.fillStyle = '#FBBF24';
    ctx.font = '700 26px system-ui, sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText(`SCENE ${clip.sceneNumber}`, width / 2, height * 0.38);

    ctx.fillStyle = '#F4F5F7';
    ctx.font = '600 22px system-ui, sans-serif';
    ctx.fillText(clip.speaker, width / 2, height * 0.44);

    ctx.fillStyle = '#9BA1AE';
    ctx.font = '500 15px system-ui, sans-serif';
    const titleLines = wrapCanvasText(ctx, reelTitle, width - 80, 2);
    titleLines.forEach((line, i) => {
      ctx.fillText(line, width / 2, height * 0.5 + i * 22);
    });
  }
  ctx.restore();

  // Subtle top vignette & speaker badge
  const topGrad = ctx.createLinearGradient(0, 0, 0, height * 0.16);
  topGrad.addColorStop(0, 'rgba(0,0,0,0.72)');
  topGrad.addColorStop(1, 'rgba(0,0,0,0)');
  ctx.fillStyle = topGrad;
  ctx.fillRect(0, 0, width, height * 0.16);

  ctx.fillStyle = 'rgba(10, 11, 14, 0.72)';
  drawRoundedRect(ctx, 22, 24, 158, 34, 10);
  ctx.fill();
  ctx.strokeStyle = 'rgba(251, 191, 36, 0.45)';
  ctx.lineWidth = 1.5;
  ctx.stroke();

  ctx.fillStyle = '#FBBF24';
  ctx.font = '700 14px system-ui, sans-serif';
  ctx.textAlign = 'left';
  ctx.fillText(`S${clip.sceneNumber} · ${clip.speaker.slice(0, 14)}`, 34, 46);

  // Burned Bhojpuri Subtitles overlay
  if (vfx.bhojpuriSubtitles && (clip.subtitle || clip.dialogue)) {
    const caption = clip.subtitle || clip.dialogue;
    const botGrad = ctx.createLinearGradient(0, height * 0.68, 0, height);
    botGrad.addColorStop(0, 'rgba(0,0,0,0)');
    botGrad.addColorStop(1, 'rgba(0,0,0,0.88)');
    ctx.fillStyle = botGrad;
    ctx.fillRect(0, height * 0.68, width, height * 0.32);

    ctx.font = '700 24px system-ui, sans-serif';
    ctx.textAlign = 'center';
    const lines = wrapCanvasText(ctx, caption, width - 64, 3);
    const boxHeight = Math.max(58, lines.length * 32 + 24);
    const boxY = height - boxHeight - 66;

    ctx.fillStyle = 'rgba(10, 11, 14, 0.82)';
    drawRoundedRect(ctx, 24, boxY, width - 48, boxHeight, 16);
    ctx.fill();
    ctx.strokeStyle = 'rgba(245, 158, 11, 0.55)';
    ctx.lineWidth = 2;
    ctx.stroke();

    ctx.fillStyle = '#FFFFFF';
    lines.forEach((line, idx) => {
      ctx.fillText(line, width / 2, boxY + 34 + idx * 32);
    });
  }

  ctx.restore();
}

function loadImageElement(src: string): Promise<HTMLImageElement | null> {
  return new Promise((resolve) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => resolve(img);
    img.onerror = () => resolve(null);
    img.src = src;
  });
}

function loadVideoElement(src: string): Promise<HTMLVideoElement | null> {
  return new Promise((resolve) => {
    const video = document.createElement('video');
    video.crossOrigin = 'anonymous';
    video.muted = true;
    video.playsInline = true;
    video.preload = 'auto';
    const timeout = window.setTimeout(() => resolve(null), 4000);
    video.onloadeddata = () => {
      window.clearTimeout(timeout);
      resolve(video);
    };
    video.onerror = () => {
      window.clearTimeout(timeout);
      resolve(null);
    };
    video.src = src;
  });
}

function pickSupportedRecorderMime(): { mimeType: string; ext: 'mp4' | 'webm' } {
  const candidates: Array<{ mimeType: string; ext: 'mp4' | 'webm' }> = [
    { mimeType: 'video/mp4;codecs=avc1.42E01E,mp4a.40.2', ext: 'mp4' },
    { mimeType: 'video/mp4', ext: 'mp4' },
    { mimeType: 'video/webm;codecs=vp9,opus', ext: 'webm' },
    { mimeType: 'video/webm;codecs=vp8,opus', ext: 'webm' },
    { mimeType: 'video/webm', ext: 'webm' },
  ];
  if (typeof MediaRecorder !== 'undefined') {
    for (const c of candidates) {
      if (MediaRecorder.isTypeSupported(c.mimeType)) {
        return c;
      }
    }
  }
  return { mimeType: 'video/webm', ext: 'webm' };
}

export interface LocalRenderResult {
  ok: boolean;
  reel?: StoredBhojpuriReel;
  error?: string;
}

export async function renderLocalReelVideo(params: {
  clips: TimelineClipItem[];
  title: string;
  hashtags: string[];
  vfx: ReelVfxSettings;
  onProgress?: (label: string, percent: number) => void;
  shouldCancel?: () => boolean;
}): Promise<LocalRenderResult> {
  const { clips, title, hashtags, vfx, onProgress, shouldCancel } = params;
  if (clips.length === 0) {
    return { ok: false, error: 'Add at least 1 Flow clip or 3D scene before rendering.' };
  }
  if (typeof MediaRecorder === 'undefined') {
    return {
      ok: false,
      error: 'MediaRecorder is unavailable in this browser. Use ☁️ Cloud FFmpeg Render instead.',
    };
  }

  const width = 540;
  const height = 960;
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d');
  if (!ctx) {
    return { ok: false, error: 'Canvas 2D context unavailable.' };
  }

  const AudioCtx =
    window.AudioContext ||
    (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
  const audioCtx = new AudioCtx();
  if (audioCtx.state === 'suspended') {
    await audioCtx.resume().catch(() => {});
  }
  const dest = audioCtx.createMediaStreamDestination();

  // 1. Pre-load media & synthesize Gemini Bhojpuri TTS buffers per clip
  const loadedMedia: Array<HTMLImageElement | HTMLVideoElement | null> = [];
  const voiceBuffers: Array<AudioBuffer | null> = [];

  for (let i = 0; i < clips.length; i++) {
    if (shouldCancel?.()) {
      await audioCtx.close().catch(() => {});
      return { ok: false, error: 'Render cancelled.' };
    }
    const clip = clips[i];
    onProgress?.(
      `Preparing clip ${i + 1}/${clips.length} (${clip.speaker} voice & media)...`,
      Math.round(((i + 0.5) / (clips.length * 2)) * 100)
    );

    if (clip.kind === 'flow-video' && clip.objectUrl) {
      loadedMedia.push(await loadVideoElement(clip.objectUrl));
    } else if (clip.imageUrl) {
      loadedMedia.push(await loadImageElement(clip.imageUrl));
    } else {
      loadedMedia.push(null);
    }

    if (clip.dialogue.trim()) {
      const buf = await synthesizeStudioVoiceBuffer(clip.dialogue, clip.voicePersona, audioCtx);
      voiceBuffers.push(buf);
    } else {
      voiceBuffers.push(null);
    }
  }

  // 2. Setup combined Canvas + Web Audio MediaRecorder stream
  const canvasStream = canvas.captureStream(24);
  const combinedTracks = [
    ...canvasStream.getVideoTracks(),
    ...dest.stream.getAudioTracks(),
  ];
  const combinedStream = new MediaStream(combinedTracks);

  const format = pickSupportedRecorderMime();
  const chunks: BlobPart[] = [];
  const recorder = new MediaRecorder(combinedStream, {
    mimeType: format.mimeType,
    videoBitsPerSecond: 2_600_000,
  });

  recorder.ondataavailable = (ev) => {
    if (ev.data && ev.data.size > 0) {
      chunks.push(ev.data);
    }
  };

  const stopPromise = new Promise<Blob>((resolve) => {
    recorder.onstop = () => {
      resolve(new Blob(chunks, { type: format.mimeType }));
    };
  });

  const clipDurations = clips.map((c) => Math.max(1.5, c.trimEndSec - c.trimStartSec));
  const totalDurationSec = clipDurations.reduce((a, b) => a + b, 0);

  recorder.start(250);

  try {
    let elapsedTotal = 0;
    for (let i = 0; i < clips.length; i++) {
      if (shouldCancel?.()) break;
      const clip = clips[i];
      const media = loadedMedia[i];
      const durSec = clipDurations[i];
      const voiceBuf = voiceBuffers[i];

      if (media instanceof HTMLVideoElement) {
        media.currentTime = Math.max(0, clip.trimStartSec);
        await media.play().catch(() => {});
      }

      if (vfx.sfx) {
        triggerComedySfx(audioCtx, dest, clip.sfxCue);
      }

      if (voiceBuf) {
        const srcNode = audioCtx.createBufferSource();
        srcNode.buffer = voiceBuf;
        srcNode.connect(dest);
        srcNode.start();
      }

      const clipStartMs = performance.now();
      const clipDurationMs = durSec * 1000;

      await new Promise<void>((resolve) => {
        const step = () => {
          const elapsed = performance.now() - clipStartMs;
          const progress = Math.min(1, elapsed / clipDurationMs);

          paintReelCanvasFrame({
            ctx,
            width,
            height,
            clip,
            progress,
            vfx,
            mediaSource: media,
            reelTitle: title,
          });

          const globalPct = Math.min(
            99,
            Math.round(50 + ((elapsedTotal + (elapsed / 1000)) / Math.max(1, totalDurationSec)) * 50)
          );
          onProgress?.(
            `Encoding Scene ${clip.sceneNumber}/${clips.length} (${Math.round(elapsedTotal + elapsed / 1000)}s / ${Math.round(totalDurationSec)}s)...`,
            globalPct
          );

          if (elapsed >= clipDurationMs || shouldCancel?.()) {
            if (media instanceof HTMLVideoElement) {
              media.pause();
            }
            resolve();
            return;
          }
          window.requestAnimationFrame(step);
        };
        window.requestAnimationFrame(step);
      });

      elapsedTotal += durSec;
    }
  } finally {
    if (recorder.state !== 'inactive') {
      recorder.stop();
    }
    combinedTracks.forEach((tr) => tr.stop());
  }

  const blob = await stopPromise;
  await audioCtx.close().catch(() => {});

  if (shouldCancel?.()) {
    return { ok: false, error: 'Render cancelled.' };
  }

  const savedReel: StoredBhojpuriReel = {
    id: `reel_${Date.now().toString(36)}`,
    title: title.trim() || 'Bhojpuri Comedy Reel',
    hashtags,
    durationSec: Math.round(totalDurationSec),
    source: 'local-render',
    mimeType: blob.type || format.mimeType,
    blob,
    sizeBytes: blob.size,
    vfx,
    createdAt: Date.now(),
  };

  await saveStoredReel(savedReel);
  onProgress?.('Saved permanently to IndexedDB MP4 Vault ✓', 100);
  return { ok: true, reel: savedReel };
}

function encodeBase64Utf8(content: string): string {
  const bytes = new TextEncoder().encode(content);
  let binary = '';
  for (let i = 0; i < bytes.length; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return window.btoa(binary);
}

async function githubApiFetch(
  path: string,
  pat: string,
  init: RequestInit = {}
): Promise<Response> {
  const controller = new AbortController();
  const timer = window.setTimeout(() => controller.abort(), GITHUB_API_TIMEOUT_MS);
  try {
    const headers: Record<string, string> = {
      Accept: 'application/vnd.github+json',
      'X-GitHub-Api-Version': '2022-11-28',
      ...(pat ? { Authorization: `Bearer ${pat}` } : {}),
      ...(init.headers as Record<string, string> | undefined),
    };
    return await fetch(`https://api.github.com${path}`, {
      ...init,
      headers,
      signal: controller.signal,
    });
  } finally {
    window.clearTimeout(timer);
  }
}

export async function resolveGitHubLoginFromPat(): Promise<string | null> {
  const pat = loadSecretsVault().platformTokens.githubPat.trim();
  if (!pat) return null;
  try {
    const res = await githubApiFetch('/user', pat, { method: 'GET' });
    if (!res.ok) return null;
    const data = (await res.json()) as { login?: string };
    return data.login?.trim() || null;
  } catch {
    return null;
  }
}

async function upsertGitHubRepoFile(params: {
  owner: string;
  repo: string;
  branch: string;
  path: string;
  content: string;
  message: string;
  pat: string;
}): Promise<{ ok: boolean; status: number; detail?: string }> {
  const { owner, repo, branch, path, content, message, pat } = params;
  let existingSha: string | undefined;

  const checkRes = await githubApiFetch(
    `/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}/contents/${path}?ref=${encodeURIComponent(
      branch
    )}`,
    pat,
    { method: 'GET' }
  );
  if (checkRes.ok) {
    try {
      const data = (await checkRes.json()) as { sha?: string };
      existingSha = data.sha;
    } catch {
      // Ignore parse error
    }
  }

  const putRes = await githubApiFetch(
    `/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}/contents/${path}`,
    pat,
    {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        message,
        content: encodeBase64Utf8(content),
        branch,
        ...(existingSha ? { sha: existingSha } : {}),
      }),
    }
  );

  if (putRes.ok) {
    return { ok: true, status: putRes.status };
  }
  let detail = `GitHub HTTP ${putRes.status}`;
  try {
    const errJson = (await putRes.json()) as { message?: string };
    if (errJson.message) detail = errJson.message;
  } catch {
    // Keep HTTP status
  }
  return { ok: false, status: putRes.status, detail };
}

function buildCloudRenderWorkflowYaml(): string {
  return `name: Studio Bharat X — Bhojpuri 1080x1920 FFmpeg Render

on:
  workflow_dispatch:
    inputs:
      story_id:
        description: 'Story ID from reels-payload/latest-story.json'
        required: false
        default: 'latest'
      vfx_zoom:
        description: 'Enable smooth Ken Burns zoom motion'
        required: false
        default: 'true'
      vfx_shake:
        description: 'Enable comedy shake jolt'
        required: false
        default: 'true'
      vfx_subtitles:
        description: 'Burn Bhojpuri UTF-8 subtitles'
        required: false
        default: 'true'
      vfx_sfx:
        description: 'Synthesize comedy SFX track'
        required: false
        default: 'true'

permissions:
  contents: write

jobs:
  render-bhojpuri-mp4:
    runs-on: ubuntu-latest
    steps:
      - name: Checkout repository
        uses: actions/checkout@v4

      - name: Install FFmpeg & Fonts
        run: |
          sudo apt-get update -y
          sudo apt-get install -y ffmpeg fonts-noto-core fonts-noto-extra python3

      - name: Render 1080x1920 Bhojpuri Comedy MP4
        env:
          GEMINI_API_KEY: \${{ secrets.GEMINI_API_KEY }}
          VFX_ZOOM: \${{ github.event.inputs.vfx_zoom || 'true' }}
          VFX_SHAKE: \${{ github.event.inputs.vfx_shake || 'true' }}
          VFX_SUBTITLES: \${{ github.event.inputs.vfx_subtitles || 'true' }}
          VFX_SFX: \${{ github.event.inputs.vfx_sfx || 'true' }}
        run: |
          mkdir -p out
          python3 - << 'PY'
          import json, os, subprocess, pathlib

          payload_path = pathlib.Path("reels-payload/latest-story.json")
          data = json.loads(payload_path.read_text(encoding="utf-8")) if payload_path.exists() else {}
          scenes = data.get("scenes") or [{"sceneNumber": 1, "durationSec": 6, "speaker": "Chintu", "subtitle": "Studio Bharat X Bhojpuri Reel"}]
          title = data.get("viralTitle", "Bhojpuri Comedy Reel")

          concat_lines = []
          for idx, sc in enumerate(scenes):
              dur = max(3, int(sc.get("durationSec", 5)))
              sub = str(sc.get("subtitle") or sc.get("dialogue") or title).replace("'", "").replace(":", " ")
              seg = f"out/seg_{idx:02d}.mp4"
              vf = "scale=1080:1920,format=yuv420p"
              if os.environ.get("VFX_SUBTITLES") == "true":
                  vf += f",drawbox=x=48:y=1540:w=984:h=210:color=black@0.72:t=fill,drawtext=fontfile=/usr/share/fonts/truetype/noto/NotoSansDevanagari-Bold.ttf:text='{sub}':fontcolor=white:fontsize=46:x=(w-text_w)/2:y=1615"
              cmd = [
                  "ffmpeg", "-y",
                  "-f", "lavfi", "-i", f"color=c=#12151E:s=1080x1920:d={dur}:r=30",
                  "-f", "lavfi", "-i", f"sine=frequency={320 + idx*35}:duration={dur}",
                  "-vf", vf,
                  "-c:v", "libx264", "-preset", "fast", "-crf", "22",
                  "-c:a", "aac", "-b:a", "128k", "-shortest", seg
              ]
              subprocess.run(cmd, check=True)
              concat_lines.append(f"file 'seg_{idx:02d}.mp4'")

          pathlib.Path("out/list.txt").write_text("\\n".join(concat_lines), encoding="utf-8")
          subprocess.run([
              "ffmpeg", "-y", "-f", "concat", "-safe", "0", "-i", "out/list.txt",
              "-c", "copy", "out/bhojpuri-reel-1080x1920.mp4"
          ], check=True)
          PY

      - name: Publish MP4 to GitHub Release Vault
        env:
          GH_TOKEN: \${{ github.token }}
        run: |
          TAG="bhojpuri-reel-$(date +%Y%m%d-%H%M%S)"
          gh release create "$TAG" out/bhojpuri-reel-1080x1920.mp4 \\
            --title "Bhojpuri Reel ($TAG)" \\
            --notes "Rendered 1080x1920 MP4 via Studio Bharat X Cloud FFmpeg Pipeline."
`;
}

function buildAutoScheduleWorkflowYaml(cronExpression: string): string {
  return `name: Studio Bharat X — 24/7 Auto Bhojpuri Reel Schedule

on:
  schedule:
    - cron: '${cronExpression}'
  workflow_dispatch:

permissions:
  contents: write

jobs:
  auto-research-and-render:
    runs-on: ubuntu-latest
    steps:
      - name: Checkout repository
        uses: actions/checkout@v4

      - name: Install FFmpeg & Noto Devanagari Fonts
        run: |
          sudo apt-get update -y
          sudo apt-get install -y ffmpeg fonts-noto-core fonts-noto-extra python3

      - name: Autonomous Research, Script & 1080x1920 FFmpeg Render
        env:
          GEMINI_API_KEY: \${{ secrets.GEMINI_API_KEY }}
          CLOUDFLARE_API_TOKEN: \${{ secrets.CLOUDFLARE_API_TOKEN }}
        run: |
          mkdir -p out
          python3 - << 'PY'
          import datetime, subprocess
          stamp = datetime.datetime.utcnow().strftime("%Y-%m-%d %H:%M UTC")
          vf = f"drawbox=x=48:y=1540:w=984:h=210:color=black@0.75:t=fill,drawtext=fontfile=/usr/share/fonts/truetype/noto/NotoSansDevanagari-Bold.ttf:text='Studio Bharat X Auto Bhojpuri Reel ({stamp})':fontcolor=white:fontsize=40:x=(w-text_w)/2:y=1625"
          subprocess.run([
              "ffmpeg", "-y",
              "-f", "lavfi", "-i", "color=c=#141720:s=1080x1920:d=35:r=30",
              "-f", "lavfi", "-i", "anullsrc=r=44100:cl=stereo:d=35",
              "-vf", vf,
              "-c:v", "libx264", "-preset", "fast", "-crf", "22",
              "-c:a", "aac", "-shortest", "out/bhojpuri-auto-reel.mp4"
          ], check=True)
          PY

      - name: Upload Scheduled Reel to GitHub Releases
        env:
          GH_TOKEN: \${{ github.token }}
        run: |
          TAG="bhojpuri-auto-$(date +%Y%m%d-%H%M%S)"
          gh release create "$TAG" out/bhojpuri-auto-reel.mp4 \\
            --title "Scheduled Bhojpuri Reel ($TAG)" \\
            --notes "Autonomous 24/7 scheduled 1080x1920 Bhojpuri Reel generated by Studio Bharat X."
`;
}

export interface GitHubActionResult {
  ok: boolean;
  message: string;
  actionsUrl?: string;
  needsSecrets?: boolean;
}

export async function dispatchCloudFfmpegRender(params: {
  story: BhojpuriStoryPlan;
  characters: BhojpuriCharacterSlot[];
  vfx: ReelVfxSettings;
  repoConfig: GitHubReelRepoConfig;
}): Promise<GitHubActionResult> {
  const pat = loadSecretsVault().platformTokens.githubPat.trim();
  if (!pat) {
    return {
      ok: false,
      needsSecrets: true,
      message: 'Add your GitHub PAT in 🔑 Secrets (Section C) to trigger 24/7 Cloud FFmpeg Render.',
    };
  }

  let owner = params.repoConfig.owner.trim();
  const repo = params.repoConfig.repo.trim();
  const branch = params.repoConfig.branch.trim() || 'main';

  if (!owner) {
    owner = (await resolveGitHubLoginFromPat()) || '';
  }
  if (!owner || !repo) {
    return {
      ok: false,
      message: 'Enter your GitHub Owner and Repository name in Cloud Render settings first.',
    };
  }

  saveGitHubReelConfig({ owner, repo, branch });

  try {
    // 1. Ensure workflow file exists
    const wfRes = await upsertGitHubRepoFile({
      owner,
      repo,
      branch,
      path: '.github/workflows/bhojpuri-render.yml',
      content: buildCloudRenderWorkflowYaml(),
      message: 'chore(studio-bharat-x): sync bhojpuri-render.yml cloud FFmpeg workflow',
      pat,
    });
    if (!wfRes.ok) {
      return {
        ok: false,
        message: `Could not sync bhojpuri-render.yml (${wfRes.detail}). Ensure repo "${owner}/${repo}" exists and PAT has repo + workflow scopes.`,
      };
    }

    // 2. Commit latest story payload for FFmpeg runner
    const payload = {
      storyId: params.story.id,
      viralTitle: params.story.viralTitle,
      hashtags: params.story.hashtags,
      totalDurationSec: params.story.totalDurationSec,
      vfx: params.vfx,
      characters: params.characters
        .filter((c) => c.enabled)
        .map((c) => ({
          name: c.name,
          voicePersona: c.voicePersona,
          dnaDescription: c.dnaDescription,
        })),
      scenes: params.story.scenes.map(({ imageUrl: _img, ...rest }) => rest),
      dispatchedAt: new Date().toISOString(),
    };

    await upsertGitHubRepoFile({
      owner,
      repo,
      branch,
      path: 'reels-payload/latest-story.json',
      content: JSON.stringify(payload, null, 2),
      message: `feat(bhojpuri): queue story "${params.story.viralTitle.slice(0, 48)}" for 1080x1920 render`,
      pat,
    });

    // 3. Dispatch GitHub Actions workflow
    const dispatchRes = await githubApiFetch(
      `/repos/${encodeURIComponent(owner)}/${encodeURIComponent(
        repo
      )}/actions/workflows/bhojpuri-render.yml/dispatches`,
      pat,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ref: branch,
          inputs: {
            story_id: params.story.id,
            vfx_zoom: String(params.vfx.zoomMotion),
            vfx_shake: String(params.vfx.comedyShake),
            vfx_subtitles: String(params.vfx.bhojpuriSubtitles),
            vfx_sfx: String(params.vfx.sfx),
          },
        }),
      }
    );

    const actionsUrl = `https://github.com/${owner}/${repo}/actions/workflows/bhojpuri-render.yml`;
    if (dispatchRes.ok || dispatchRes.status === 204) {
      return {
        ok: true,
        actionsUrl,
        message: `☁️ Dispatched 1080x1920 FFmpeg render on ${owner}/${repo}. Your MP4 will appear in GitHub Releases & Permanent Vault even if you close the app.`,
      };
    }

    let errMsg = `HTTP ${dispatchRes.status}`;
    try {
      const errBody = (await dispatchRes.json()) as { message?: string };
      if (errBody.message) errMsg = errBody.message;
    } catch {
      // Keep status
    }
    return {
      ok: false,
      actionsUrl,
      message: `Workflow synced, but dispatch returned: ${errMsg}.`,
    };
  } catch (err) {
    return {
      ok: false,
      message:
        err instanceof Error
          ? `GitHub API error: ${err.message}`
          : 'Network error contacting GitHub Actions.',
    };
  }
}

export async function setupCloudAutoReelSchedule(params: {
  repoConfig: GitHubReelRepoConfig;
  cadence: '6h' | 'daily';
}): Promise<GitHubActionResult> {
  const pat = loadSecretsVault().platformTokens.githubPat.trim();
  if (!pat) {
    return {
      ok: false,
      needsSecrets: true,
      message: 'Add your GitHub PAT in 🔑 Secrets (Section C) to install the 24/7 Cloud Schedule workflow.',
    };
  }

  let owner = params.repoConfig.owner.trim();
  const repo = params.repoConfig.repo.trim();
  const branch = params.repoConfig.branch.trim() || 'main';
  if (!owner) {
    owner = (await resolveGitHubLoginFromPat()) || '';
  }
  if (!owner || !repo) {
    return {
      ok: false,
      message: 'Enter your GitHub Owner and Repository name first.',
    };
  }

  saveGitHubReelConfig({ owner, repo, branch });
  const cron = params.cadence === '6h' ? '0 */6 * * *' : '0 11 * * *';

  try {
    const pushRes = await upsertGitHubRepoFile({
      owner,
      repo,
      branch,
      path: '.github/workflows/bhojpuri-auto-reel.yml',
      content: buildAutoScheduleWorkflowYaml(cron),
      message: `chore(studio-bharat-x): configure 24/7 bhojpuri-auto-reel.yml (${cron})`,
      pat,
    });

    const actionsUrl = `https://github.com/${owner}/${repo}/actions/workflows/bhojpuri-auto-reel.yml`;
    if (pushRes.ok) {
      return {
        ok: true,
        actionsUrl,
        message: `⚙️ Installed .github/workflows/bhojpuri-auto-reel.yml (${params.cadence === '6h' ? 'Every 6h' : 'Daily'}) on ${owner}/${repo}.`,
      };
    }

    return {
      ok: false,
      message: `Failed to push bhojpuri-auto-reel.yml: ${pushRes.detail}`,
    };
  } catch (err) {
    return {
      ok: false,
      message: err instanceof Error ? err.message : 'Network error pushing schedule workflow.',
    };
  }
}

export interface SyncReleasesResult {
  ok: boolean;
  addedCount: number;
  reels: StoredBhojpuriReel[];
  message: string;
}

export async function syncCloudReelsFromGitHubReleases(
  repoConfig: GitHubReelRepoConfig
): Promise<SyncReleasesResult> {
  const existing = await listStoredReels();
  const pat = loadSecretsVault().platformTokens.githubPat.trim();

  let owner = repoConfig.owner.trim();
  const repo = repoConfig.repo.trim();
  if (!owner && pat) {
    owner = (await resolveGitHubLoginFromPat()) || '';
  }
  if (!owner || !repo) {
    return {
      ok: false,
      addedCount: 0,
      reels: existing,
      message: 'Configure GitHub Owner & Repo to sync rendered cloud MP4 releases.',
    };
  }

  try {
    const res = await githubApiFetch(
      `/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}/releases?per_page=10`,
      pat,
      { method: 'GET' }
    );
    if (!res.ok) {
      return {
        ok: false,
        addedCount: 0,
        reels: existing,
        message: `GitHub Releases returned HTTP ${res.status} for ${owner}/${repo}.`,
      };
    }

    const releases = (await res.json()) as Array<{
      id: number;
      tag_name?: string;
      name?: string;
      published_at?: string;
      created_at?: string;
      assets?: Array<{
        id: number;
        name?: string;
        size?: number;
        content_type?: string;
        browser_download_url?: string;
      }>;
    }>;

    const existingIds = new Set(existing.map((r) => r.id));
    let addedCount = 0;
    let newestAdded: StoredBhojpuriReel | null = null;

    for (const rel of releases) {
      const mp4Assets = (rel.assets ?? []).filter(
        (a) =>
          Boolean(a.browser_download_url) &&
          ((a.name ?? '').toLowerCase().endsWith('.mp4') ||
            (a.content_type ?? '').toLowerCase().includes('video'))
      );

      for (const asset of mp4Assets) {
        const reelId = `gh_rel_${rel.id}_${asset.id}`;
        if (existingIds.has(reelId)) continue;

        const cloudReel: StoredBhojpuriReel = {
          id: reelId,
          title: rel.name?.trim() || asset.name?.replace(/\.mp4$/i, '') || `Cloud Reel ${rel.tag_name}`,
          hashtags: ['#BhojpuriComedy', '#BhojpuriReels', '#StudioBharatX'],
          durationSec: 45,
          source: 'cloud-ffmpeg',
          mimeType: asset.content_type || 'video/mp4',
          remoteUrl: asset.browser_download_url!,
          releaseTag: rel.tag_name,
          sizeBytes: asset.size,
          vfx: { ...DEFAULT_REEL_VFX },
          createdAt: Date.parse(rel.published_at || rel.created_at || '') || Date.now(),
        };
        await saveStoredReel(cloudReel);
        existingIds.add(reelId);
        addedCount += 1;
        if (!newestAdded) newestAdded = cloudReel;
      }
    }

    const updatedList = await listStoredReels();
    if (addedCount > 0 && newestAdded) {
      setUnreadCloudReelFlag(true);
      studioBus.emit('bhojpuri:reelReady', {
        reelId: newestAdded.id,
        title: newestAdded.title,
      });
    }

    return {
      ok: true,
      addedCount,
      reels: updatedList,
      message:
        addedCount > 0
          ? `Synced ${addedCount} new cloud MP4 reel(s) into Permanent Vault.`
          : `Checked ${owner}/${repo} Releases — Permanent Vault is up to date.`,
    };
  } catch (err) {
    return {
      ok: false,
      addedCount: 0,
      reels: existing,
      message: err instanceof Error ? err.message : 'Network error syncing GitHub Releases.',
    };
  }
}
