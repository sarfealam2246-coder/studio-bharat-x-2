import { ProjectFile } from '../types/studio';

export const THREE_CDN_SCRIPT =
  'https://cdn.jsdelivr.net/npm/three@0.149.0/build/three.min.js';

export interface PreviewSpyPayload {
  type: 'STUDIO_PREVIEW_SPY';
  department: 'gaming' | 'apps';
  nonce: string;
  level: 'ok' | 'warn' | 'error';
  kind: 'runtime' | 'rejection' | 'console' | 'webgl' | 'blank-canvas' | 'ready';
  message: string;
  line?: number;
}

export function isPreviewSpyPayload(data: unknown): data is PreviewSpyPayload {
  if (!data || typeof data !== 'object') return false;
  const obj = data as Partial<PreviewSpyPayload>;
  return (
    obj.type === 'STUDIO_PREVIEW_SPY' &&
    (obj.department === 'gaming' || obj.department === 'apps') &&
    typeof obj.nonce === 'string' &&
    typeof obj.message === 'string'
  );
}

/**
 * Android WebView & Sandbox Safety:
 * Strips <script type="importmap"> and esm.sh imports cleanly.
 */
export function sanitizeForAndroidSandbox(code: string): string {
  return code
    .replace(/<script[^>]*type=["']importmap["'][^>]*>[\s\S]*?<\/script>/gi, '')
    .replace(/import\s+[\s\S]*?from\s+["']https?:\/\/esm\.sh[^"']*["'];?/gi, '')
    .replace(/https?:\/\/esm\.sh\/three[^\s"'`)]*/gi, THREE_CDN_SCRIPT);
}

export function needsThreeJsLibrary(html: string, js: string, department: 'gaming' | 'apps'): boolean {
  if (department !== 'gaming') return false;
  const combined = `${html}\n${js}`;
  return /\bTHREE\b|WebGLRenderer|PerspectiveCamera|BoxGeometry|three\.min\.js/i.test(combined);
}

function buildSpyInjectionScript(department: 'gaming' | 'apps', nonce: string): string {
  return `<script>
(function(){
  var DEPT = ${JSON.stringify(department)};
  var NONCE = ${JSON.stringify(nonce)};
  var hasError = false;
  function emit(level, kind, message, line) {
    try {
      window.parent.postMessage({
        type: 'STUDIO_PREVIEW_SPY',
        department: DEPT,
        nonce: NONCE,
        level: level,
        kind: kind,
        message: String(message || '').slice(0, 280),
        line: typeof line === 'number' ? line : undefined
      }, '*');
    } catch (e) {}
  }

  window.addEventListener('error', function(ev) {
    hasError = true;
    emit('error', 'runtime', ev.message || 'Runtime script error', ev.lineno);
  });

  window.addEventListener('unhandledrejection', function(ev) {
    hasError = true;
    var reason = ev.reason && ev.reason.message ? ev.reason.message : String(ev.reason || 'Unhandled promise rejection');
    emit('error', 'rejection', reason);
  });

  var origError = console.error;
  console.error = function() {
    hasError = true;
    try {
      var msg = Array.prototype.slice.call(arguments).map(function(a) {
        return typeof a === 'object' ? JSON.stringify(a) : String(a);
      }).join(' ');
      emit('error', 'console', msg || 'console.error triggered');
    } catch (e) {
      emit('error', 'console', 'console.error triggered');
    }
    if (origError) return origError.apply(console, arguments);
  };

  // Detect WebGL context failure cleanly
  var origGetContext = HTMLCanvasElement && HTMLCanvasElement.prototype && HTMLCanvasElement.prototype.getContext;
  if (origGetContext) {
    HTMLCanvasElement.prototype.getContext = function(type) {
      var ctx = origGetContext.apply(this, arguments);
      if (!ctx && (type === 'webgl' || type === 'webgl2' || type === 'experimental-webgl')) {
        hasError = true;
        emit('error', 'webgl', 'WebGL context initialization failed (' + type + ')');
      }
      return ctx;
    };
  }

  // Post-load blank-canvas & empty-stage check
  window.addEventListener('load', function() {
    setTimeout(function() {
      try {
        var canvases = document.querySelectorAll('canvas');
        var bodyText = (document.body && document.body.innerText ? document.body.innerText : '').trim();
        var hasSvgOrImg = document.querySelectorAll('svg, img, button, input').length > 0;

        if (canvases.length > 0) {
          var validCanvas = false;
          for (var i = 0; i < canvases.length; i++) {
            var rect = canvases[i].getBoundingClientRect();
            if (rect.width > 8 && rect.height > 8) {
              validCanvas = true;
              break;
            }
          }
          if (!validCanvas) {
            hasError = true;
            emit('error', 'blank-canvas', 'Canvas rendered with 0x0 or collapsed dimensions');
            return;
          }
        } else if (!bodyText && !hasSvgOrImg) {
          hasError = true;
          emit('error', 'blank-canvas', 'Preview rendered blank with no visible content');
          return;
        }

        if (!hasError) {
          emit('ok', 'ready', 'Preview mounted cleanly');
        }
      } catch (err) {
        emit('warn', 'runtime', 'Health check warning');
      }
    }, 1300);
  });
})();
</script>`;
}

export function buildSandboxedSrcDoc(
  files: ProjectFile[],
  department: 'gaming' | 'apps',
  nonce: string
): string | null {
  const htmlFile = files.find((f) => f.path.toLowerCase() === 'index.html');
  const cssFile = files.find((f) => f.path.toLowerCase() === 'styles.css');
  const jsFile = files.find((f) => f.path.toLowerCase() === 'app.js');

  if (!htmlFile && !cssFile && !jsFile) {
    return null;
  }

  let html = sanitizeForAndroidSandbox(
    htmlFile?.content?.trim() ||
      `<!doctype html>
<html lang="en">
<head><meta charset="UTF-8" /><meta name="viewport" content="width=device-width, initial-scale=1.0" /><title>Preview</title></head>
<body><div id="app"></div></body>
</html>`
  );
  const css = cssFile?.content ?? '';
  const js = sanitizeForAndroidSandbox(jsFile?.content ?? '');

  // Strip local relative script/link tags for styles.css & app.js since we inline them cleanly
  html = html
    .replace(/<link[^>]*href=["'](?:\.\/)?styles\.css["'][^>]*>/gi, '')
    .replace(/<script[^>]*src=["'](?:\.\/)?app\.js["'][^>]*>\s*<\/script>/gi, '');

  const spyScript = buildSpyInjectionScript(department, nonce);
  const threeTag =
    needsThreeJsLibrary(html, js, department) && !html.includes('three.min.js')
      ? `<script src="${THREE_CDN_SCRIPT}"></script>`
      : '';
  const styleTag = css.trim()
    ? `<style id="studio-bharat-styles">\n${css}\n</style>`
    : '';
  const safeJs = js.replace(/<\/script>/gi, '<\\/script>');
  const appScriptTag = safeJs.trim()
    ? `<script id="studio-bharat-app">\n${safeJs}\n</script>`
    : '';

  if (/<head[^>]*>/i.test(html)) {
    html = html.replace(/<head[^>]*>/i, (match) => `${match}\n${spyScript}\n${threeTag}\n${styleTag}`);
  } else {
    html = `<!doctype html><html><head>${spyScript}${threeTag}${styleTag}</head><body>${html}</body></html>`;
  }

  if (/<\/body>/i.test(html)) {
    html = html.replace(/<\/body>/i, `${appScriptTag}\n</body>`);
  } else {
    html = `${html}\n${appScriptTag}`;
  }

  return html;
}
